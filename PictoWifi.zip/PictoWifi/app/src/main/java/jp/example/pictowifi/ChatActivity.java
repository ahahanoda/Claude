package jp.example.pictowifi;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.DhcpInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.util.Base64;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/**
 * ピクトチャット風 WiFi チャット。
 * 同じLAN内で UDP ブロードキャストを使い、サーバー不要で通信する。
 * パケット形式: PCT1|ルーム|種別(T/D/J/L)|送信者ID|名前|本文
 */
public class ChatActivity extends Activity {
    static final int PORT = 49152;
    static final String MAGIC = "PCT1";
    static final String[] ROOMS = { "A", "B", "C", "D" };
    static final int[] ROOM_COLORS = { 0xFF3DAA5C, 0xFFE0A030, 0xFF3A8FD8, 0xFFD85A8A };
    static final int MAX_B64 = 60000;

    private final String myId = Long.toHexString(System.nanoTime())
            + Integer.toHexString(new Random().nextInt());
    private String myName;
    private int room = 0;
    private boolean started = false;

    private volatile DatagramSocket socket;
    private volatile boolean running;
    private WifiManager.MulticastLock mlock;
    private final ExecutorService sender = Executors.newSingleThreadExecutor();
    private final Handler ui = new Handler();

    private LinearLayout list;
    private ScrollView scroll;
    private DrawView draw;
    private EditText input;
    private final Button[] roomBtns = new Button[ROOMS.length];
    private TextView status;

    // ---------------------------------------------------------------- UI
    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private Button makeButton(String label, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(13);
        b.setOnClickListener(l);
        return b;
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFFE8E4F0);
        root.setPadding(dp(4), dp(4), dp(4), dp(4));

        status = new TextView(this);
        status.setTextSize(12);
        status.setTextColor(0xFF333333);
        root.addView(status);

        // ルーム選択
        LinearLayout rooms = new LinearLayout(this);
        rooms.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < ROOMS.length; i++) {
            final int idx = i;
            roomBtns[i] = makeButton("ルーム" + ROOMS[i], new View.OnClickListener() {
                public void onClick(View v) { selectRoom(idx); }
            });
            rooms.addView(roomBtns[i], new LinearLayout.LayoutParams(0,
                    LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        }
        root.addView(rooms);

        // メッセージ一覧
        scroll = new ScrollView(this);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(list, new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT, ScrollView.LayoutParams.WRAP_CONTENT));
        root.addView(scroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        // お絵かきキャンバス
        draw = new DrawView(this);
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        dlp.topMargin = dp(4);
        root.addView(draw, dlp);

        // ツール行
        LinearLayout tools = new LinearLayout(this);
        tools.setOrientation(LinearLayout.HORIZONTAL);
        String[] labels = { "ペン", "消しゴム", "全消し", "絵を送信" };
        View.OnClickListener[] ls = new View.OnClickListener[] {
            new View.OnClickListener() { public void onClick(View v) { draw.setEraser(false); } },
            new View.OnClickListener() { public void onClick(View v) { draw.setEraser(true); } },
            new View.OnClickListener() { public void onClick(View v) { draw.clear(); } },
            new View.OnClickListener() { public void onClick(View v) { sendDrawing(); } }
        };
        for (int i = 0; i < labels.length; i++) {
            tools.addView(makeButton(labels[i], ls[i]), new LinearLayout.LayoutParams(0,
                    LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        }
        root.addView(tools);

        // テキスト入力行
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        input = new EditText(this);
        input.setSingleLine(true);
        input.setHint("メッセージ");
        row.addView(input, new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(makeButton("送信", new View.OnClickListener() {
            public void onClick(View v) { sendText(); }
        }), new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));
        root.addView(row);

        setContentView(root);
    }

    private void updateRoomButtons() {
        for (int i = 0; i < ROOMS.length; i++) {
            if (i == room) {
                roomBtns[i].setBackgroundColor(ROOM_COLORS[i]);
                roomBtns[i].setTextColor(Color.WHITE);
            } else {
                roomBtns[i].setBackgroundColor(0xFFBBBBBB);
                roomBtns[i].setTextColor(Color.BLACK);
            }
        }
        status.setText("あなた: " + myName + "  /  ルーム" + ROOMS[room]);
    }

    private void addSystem(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(12);
        t.setTextColor(0xFF777777);
        t.setGravity(Gravity.CENTER_HORIZONTAL);
        addToList(t, null);
    }

    private void addBubble(String name, String text, Bitmap bmp, boolean mine) {
        LinearLayout b = new LinearLayout(this);
        b.setOrientation(LinearLayout.VERTICAL);
        b.setPadding(dp(8), dp(4), dp(8), dp(6));
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.WHITE);
        g.setCornerRadius(dp(6));
        g.setStroke(dp(2), ROOM_COLORS[room]);
        b.setBackgroundDrawable(g);

        TextView n = new TextView(this);
        n.setText(name);
        n.setTextSize(11);
        n.setTextColor(mine ? 0xFF1A7F3C : 0xFF555555);
        b.addView(n);

        if (text != null) {
            TextView t = new TextView(this);
            t.setText(text);
            t.setTextSize(16);
            t.setTextColor(Color.BLACK);
            b.addView(t);
        }
        if (bmp != null) {
            ImageView iv = new ImageView(this);
            Bitmap big = Bitmap.createScaledBitmap(bmp, bmp.getWidth() * 2, bmp.getHeight() * 2, false);
            iv.setImageBitmap(big);
            iv.setAdjustViewBounds(true);
            b.addView(iv, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        }
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(mine ? dp(40) : dp(4), dp(3), mine ? dp(4) : dp(40), dp(3));
        addToList(b, lp);
    }

    private void addToList(View v, LinearLayout.LayoutParams lp) {
        if (list.getChildCount() > 100) list.removeViewAt(0);
        if (lp == null) list.addView(v); else list.addView(v, lp);
        scroll.post(new Runnable() {
            public void run() { scroll.fullScroll(View.FOCUS_DOWN); }
        });
    }

    // ---------------------------------------------------------------- lifecycle
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        buildUi();
        SharedPreferences p = getSharedPreferences("pw", MODE_PRIVATE);
        myName = p.getString("name", null);
        if (myName == null) {
            askName("ゲスト" + (new Random().nextInt(900) + 100));
        } else {
            begin();
        }
    }

    private void askName(String def) {
        final EditText et = new EditText(this);
        et.setText(def);
        et.setSingleLine(true);
        new AlertDialog.Builder(this)
            .setTitle("ニックネーム")
            .setView(et)
            .setCancelable(started)
            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int w) {
                    String n = et.getText().toString().replace('|', '/').trim();
                    if (n.length() == 0) n = "ゲスト";
                    if (n.length() > 12) n = n.substring(0, 12);
                    myName = n;
                    getSharedPreferences("pw", MODE_PRIVATE).edit().putString("name", n).commit();
                    if (!started) begin(); else updateRoomButtons();
                }
            }).show();
    }

    private void begin() {
        started = true;
        startNet();
        updateRoomButtons();
        addSystem("ルーム" + ROOMS[room] + "に入室しました");
        sendPacket("J", "");
    }

    @Override
    public boolean onCreateOptionsMenu(Menu m) {
        m.add(0, 1, 0, "名前変更");
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem i) {
        if (i.getItemId() == 1) askName(myName);
        return true;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (started) {
            sendPacket("L", "");
            running = false;
            sender.execute(new Runnable() {
                public void run() {
                    DatagramSocket s = socket;
                    if (s != null) s.close();
                    if (mlock != null && mlock.isHeld()) mlock.release();
                }
            });
        }
        sender.shutdown();
    }

    // ---------------------------------------------------------------- actions
    private void selectRoom(int r) {
        if (!started || r == room) return;
        sendPacket("L", "");
        room = r;
        list.removeAllViews();
        updateRoomButtons();
        addSystem("ルーム" + ROOMS[room] + "に入室しました");
        sendPacket("J", "");
    }

    private void sendText() {
        String t = input.getText().toString().trim();
        if (t.length() == 0 || !started) return;
        if (t.length() > 200) t = t.substring(0, 200);
        sendPacket("T", t);
        addBubble(myName, t, null, true);
        input.setText("");
    }

    private void sendDrawing() {
        if (!started) return;
        if (!draw.isDirty()) {
            Toast.makeText(this, "何も描かれていません", Toast.LENGTH_SHORT).show();
            return;
        }
        String b64 = Base64.encodeToString(draw.toPng(), Base64.NO_WRAP);
        if (b64.length() > MAX_B64) {
            Toast.makeText(this, "絵が大きすぎます", Toast.LENGTH_SHORT).show();
            return;
        }
        sendPacket("D", b64);
        addBubble(myName, null, draw.copyBitmap(), true);
        draw.clear();
    }

    // ---------------------------------------------------------------- network
    private void startNet() {
        WifiManager wm = (WifiManager) getSystemService(WIFI_SERVICE);
        if (wm.getConnectionInfo() == null || wm.getConnectionInfo().getIpAddress() == 0) {
            Toast.makeText(this, "Wi-Fiに接続してください(テザリングでも可)", Toast.LENGTH_LONG).show();
        }
        mlock = wm.createMulticastLock("pictowifi");
        mlock.setReferenceCounted(false);
        mlock.acquire();

        running = true;
        new Thread(new Runnable() {
            public void run() {
                DatagramSocket s;
                try {
                    s = new DatagramSocket(null);
                    s.setReuseAddress(true);
                    s.setBroadcast(true);
                    s.bind(new InetSocketAddress(PORT));
                    socket = s;
                } catch (IOException e) {
                    ui.post(new Runnable() { public void run() {
                        Toast.makeText(ChatActivity.this, "通信を開始できません", Toast.LENGTH_LONG).show();
                    }});
                    return;
                }
                byte[] buf = new byte[65535];
                while (running) {
                    try {
                        DatagramPacket p = new DatagramPacket(buf, buf.length);
                        s.receive(p);
                        final String msg = new String(p.getData(), 0, p.getLength(), "UTF-8");
                        ui.post(new Runnable() { public void run() { handle(msg); } });
                    } catch (IOException e) {
                        if (!running) break;
                    }
                }
            }
        }).start();
    }

    private InetAddress broadcastAddr() {
        try {
            WifiManager wm = (WifiManager) getSystemService(WIFI_SERVICE);
            DhcpInfo d = wm.getDhcpInfo();
            if (d != null && d.ipAddress != 0 && d.netmask != 0) {
                int b = (d.ipAddress & d.netmask) | ~d.netmask;
                byte[] q = new byte[4];
                for (int i = 0; i < 4; i++) q[i] = (byte) ((b >> (i * 8)) & 0xFF);
                return InetAddress.getByAddress(q);
            }
        } catch (Exception e) { /* fallthrough */ }
        try { return InetAddress.getByName("255.255.255.255"); } catch (Exception e) { return null; }
    }

    private void sendPacket(String type, String payload) {
        final String s = MAGIC + "|" + ROOMS[room] + "|" + type + "|" + myId + "|" + myName + "|" + payload;
        sender.execute(new Runnable() {
            public void run() {
                DatagramSocket sk = socket;
                InetAddress addr = broadcastAddr();
                if (sk == null || addr == null) return;
                try {
                    byte[] data = s.getBytes("UTF-8");
                    sk.send(new DatagramPacket(data, data.length, addr, PORT));
                } catch (IOException e) { /* 無視 */ }
            }
        });
    }

    private void handle(String msg) {
        String[] f = msg.split("\\|", 6);
        if (f.length < 6 || !MAGIC.equals(f[0])) return;
        if (!ROOMS[room].equals(f[1])) return;   // 別ルームは無視
        if (myId.equals(f[3])) return;           // 自分の発言は無視
        String type = f[2], name = f[4], body = f[5];
        if ("T".equals(type)) {
            addBubble(name, body, null, false);
        } else if ("D".equals(type)) {
            try {
                byte[] png = Base64.decode(body, Base64.DEFAULT);
                Bitmap bmp = BitmapFactory.decodeByteArray(png, 0, png.length);
                if (bmp != null && bmp.getWidth() <= 512 && bmp.getHeight() <= 512) {
                    addBubble(name, null, bmp, false);
                }
            } catch (Exception e) { /* 壊れたデータは無視 */ }
        } else if ("J".equals(type)) {
            addSystem(name + " さんが入室しました");
        } else if ("L".equals(type)) {
            addSystem(name + " さんが退室しました");
        }
    }
}
