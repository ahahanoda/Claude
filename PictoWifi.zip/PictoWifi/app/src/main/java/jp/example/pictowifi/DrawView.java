package jp.example.pictowifi;

import java.io.ByteArrayOutputStream;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.view.MotionEvent;
import android.view.View;

/** DS風の手書きキャンバス (256x96 の白黒ドット絵) */
public class DrawView extends View {
    public static final int BW = 256;
    public static final int BH = 96;

    private final Bitmap bmp;
    private final Canvas cv;
    private final Paint pen = new Paint();
    private final Paint eraser = new Paint();
    private final Paint bmpPaint = new Paint();
    private final Paint border = new Paint();
    private Paint cur;
    private final Rect dst = new Rect();
    private float lastX, lastY;
    private boolean dirty = false;

    public DrawView(Context c) {
        super(c);
        bmp = Bitmap.createBitmap(BW, BH, Bitmap.Config.ARGB_8888);
        cv = new Canvas(bmp);
        cv.drawColor(Color.WHITE);

        pen.setColor(Color.BLACK);
        pen.setAntiAlias(false);          // 白黒のみ → PNGが小さくなる
        pen.setStrokeWidth(2f);
        pen.setStrokeCap(Paint.Cap.ROUND);

        eraser.setColor(Color.WHITE);
        eraser.setAntiAlias(false);
        eraser.setStrokeWidth(10f);
        eraser.setStrokeCap(Paint.Cap.ROUND);

        bmpPaint.setFilterBitmap(false);  // ドットをくっきり表示

        border.setColor(0xFF444444);
        border.setStyle(Paint.Style.STROKE);
        border.setStrokeWidth(3f);

        cur = pen;
    }

    public void setEraser(boolean on) { cur = on ? eraser : pen; }

    public void clear() {
        cv.drawColor(Color.WHITE);
        dirty = false;
        invalidate();
    }

    public boolean isDirty() { return dirty; }

    /** 現在の絵のコピー */
    public Bitmap copyBitmap() { return bmp.copy(Bitmap.Config.ARGB_8888, false); }

    public byte[] toPng() {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.PNG, 100, out);
        return out.toByteArray();
    }

    @Override
    protected void onMeasure(int wSpec, int hSpec) {
        int w = MeasureSpec.getSize(wSpec);
        int h = w * BH / BW;
        int maxH = getResources().getDisplayMetrics().heightPixels / 3;
        if (h > maxH) h = maxH;
        setMeasuredDimension(w, h);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        int w = getWidth(), h = getHeight();
        float s = Math.min((float) w / BW, (float) h / BH);
        int dw = (int) (BW * s), dh = (int) (BH * s);
        int l = (w - dw) / 2, t = (h - dh) / 2;
        dst.set(l, t, l + dw, t + dh);
        canvas.drawBitmap(bmp, null, dst, bmpPaint);
        canvas.drawRect(dst, border);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (dst.width() == 0) return true;
        float bx = (e.getX() - dst.left) * BW / dst.width();
        float by = (e.getY() - dst.top) * BH / dst.height();
        switch (e.getAction()) {
            case MotionEvent.ACTION_DOWN:
                cv.drawPoint(bx, by, cur);
                lastX = bx; lastY = by; dirty = true;
                break;
            case MotionEvent.ACTION_MOVE:
                cv.drawLine(lastX, lastY, bx, by, cur);
                lastX = bx; lastY = by; dirty = true;
                break;
        }
        invalidate();
        return true;
    }
}
