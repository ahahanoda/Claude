package com.example.wifichat;

import java.io.UnsupportedEncodingException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

import android.app.Activity;
import android.content.Context;
import android.net.DhcpInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

/**
 * 同一Wi-Fi内でUDPブロードキャストを使うサーバ不要のチャット。
 * Android 2.3 (API 10) 互換: Java 6構文、サポートライブラリ不使用。
 */
public class ChatActivity extends Activity {

    private static final int PORT = 50000;
    private static final String MAGIC = "WCHAT1";
    private static final String SEP = "\t";

    private final String myId =
            Long.toHexString(System.nanoTime()) + Integer.toHexString(new Random().nextInt());
    private final Handler handler = new Handler();
    private final SimpleDateFormat fmt = new SimpleDateFormat("HH:mm");

    private ArrayAdapter<String> adapter;
    private EditText nameEdit;
    private EditText msgEdit;
    private TextView statusView;

    private volatile DatagramSocket socket;
    private volatile boolean running;
    private WifiManager.MulticastLock multicastLock;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        statusView = (TextView) findViewById(R.id.status);
        nameEdit = (EditText) findViewById(R.id.name);
        msgEdit = (EditText) findViewById(R.id.msg);
        Button sendBtn = (Button) findViewById(R.id.send);
        ListView list = (ListView) findViewById(R.id.list);

        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1);
        list.setAdapter(adapter);

        nameEdit.setText("user" + (new Random().nextInt(900) + 100));

        sendBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                sendMessage();
            }
        });

        WifiManager wm = (WifiManager) getSystemService(Context.WIFI_SERVICE);
        multicastLock = wm.createMulticastLock("wifichat");
        multicastLock.setReferenceCounted(false);
    }

    @Override
    protected void onStart() {
        super.onStart();
        multicastLock.acquire();
        startReceiver();
        updateStatus();
    }

    @Override
    protected void onStop() {
        super.onStop();
        stopReceiver();
        if (multicastLock.isHeld()) {
            multicastLock.release();
        }
    }

    private void updateStatus() {
        WifiManager wm = (WifiManager) getSystemService(Context.WIFI_SERVICE);
        String s;
        if (!wm.isWifiEnabled()) {
            s = "Wi-FiがOFFです";
            Toast.makeText(this, "Wi-FiをONにしてください", Toast.LENGTH_LONG).show();
        } else {
            WifiInfo info = wm.getConnectionInfo();
            if (info == null || info.getIpAddress() == 0) {
                s = "Wi-Fi未接続";
            } else {
                s = "SSID: " + info.getSSID() + " / IP: " + ipToString(info.getIpAddress())
                        + " / ポート " + PORT;
            }
        }
        statusView.setText(s);
    }

    private static String ipToString(int ip) {
        return (ip & 0xFF) + "." + ((ip >> 8) & 0xFF) + "." + ((ip >> 16) & 0xFF) + "."
                + ((ip >> 24) & 0xFF);
    }

    // ---------- 受信 ----------

    private void startReceiver() {
        if (running) return;
        running = true;
        new Thread(new Runnable() {
            public void run() {
                DatagramSocket s = null;
                try {
                    s = new DatagramSocket(null);
                    s.setReuseAddress(true);
                    s.setBroadcast(true);
                    s.bind(new InetSocketAddress(PORT));
                    socket = s;
                    byte[] buf = new byte[2048];
                    while (running) {
                        DatagramPacket p = new DatagramPacket(buf, buf.length);
                        s.receive(p);
                        handlePacket(p);
                    }
                } catch (final Exception e) {
                    if (running) {
                        postLine("[受信エラー] " + e.getMessage());
                    }
                } finally {
                    if (s != null) s.close();
                    socket = null;
                }
            }
        }, "wifichat-recv").start();
    }

    private void stopReceiver() {
        running = false;
        DatagramSocket s = socket;
        if (s != null) s.close(); // receive() を中断させる
    }

    private void handlePacket(DatagramPacket p) {
        try {
            String text = new String(p.getData(), 0, p.getLength(), "UTF-8");
            String[] parts = text.split(SEP, 4);
            if (parts.length < 4 || !MAGIC.equals(parts[0])) return;
            if (myId.equals(parts[1])) return; // 自分のエコーは無視
            postLine(fmt.format(new Date()) + " " + parts[2] + ": " + parts[3]);
        } catch (UnsupportedEncodingException e) {
            // UTF-8は必ず存在する
        }
    }

    // ---------- 送信 ----------

    private void sendMessage() {
        final String msg = msgEdit.getText().toString().trim();
        if (msg.length() == 0) return;
        String n = nameEdit.getText().toString().trim();
        if (n.length() == 0) n = "noname";
        final String name = n.replace(SEP, " ");
        final String body = msg.replace(SEP, " ");

        postLine(fmt.format(new Date()) + " " + name + "(自分): " + body);
        msgEdit.setText("");

        final InetAddress target = getBroadcastAddress();
        new Thread(new Runnable() {
            public void run() {
                try {
                    byte[] data = (MAGIC + SEP + myId + SEP + name + SEP + body).getBytes("UTF-8");
                    DatagramSocket s = socket;
                    boolean temp = false;
                    if (s == null) {
                        s = new DatagramSocket();
                        s.setBroadcast(true);
                        temp = true;
                    }
                    s.send(new DatagramPacket(data, data.length, target, PORT));
                    if (temp) s.close();
                } catch (Exception e) {
                    postLine("[送信エラー] " + e.getMessage());
                }
            }
        }, "wifichat-send").start();
    }

    private InetAddress getBroadcastAddress() {
        try {
            WifiManager wm = (WifiManager) getSystemService(Context.WIFI_SERVICE);
            DhcpInfo d = wm.getDhcpInfo();
            if (d != null && d.ipAddress != 0 && d.netmask != 0) {
                int b = (d.ipAddress & d.netmask) | ~d.netmask;
                byte[] q = new byte[4];
                for (int i = 0; i < 4; i++) {
                    q[i] = (byte) ((b >> (i * 8)) & 0xFF);
                }
                return InetAddress.getByAddress(q);
            }
        } catch (Exception e) {
            // フォールバックへ
        }
        try {
            return InetAddress.getByName("255.255.255.255");
        } catch (Exception e) {
            return null;
        }
    }

    private void postLine(final String line) {
        handler.post(new Runnable() {
            public void run() {
                adapter.add(line);
            }
        });
    }
}
