package com.example.wifichat;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.net.DhcpInfo;
import android.net.Uri;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

/**
 * 同一Wi-Fi内のサーバ不要チャット (Android 2.3 / API 10 互換)
 *  - メッセージ: UDPブロードキャスト (ポート50000)
 *  - ファイル/お絵描き: UDPで「ファイル提供のお知らせ」を配信し、
 *    受信側がタップすると送信元へTCP (ポート50001) で接続して取得する
 */
public class ChatActivity extends Activity {

    private static final int PORT = 50000;       // UDP
    private static final int FILE_PORT = 50001;  // TCP
    private static final String MAGIC = "WCHAT2";
    private static final String SEP = "\t";

    private final String myId =
            Long.toHexString(System.nanoTime()) + Integer.toHexString(new Random().nextInt());
    private final Handler handler = new Handler();
    private final Map<String, File> sharedFiles = new ConcurrentHashMap<String, File>();

    private ArrayAdapter<Item> adapter;
    private EditText nameEdit;
    private EditText msgEdit;
    private TextView statusView;
    private Dialog pickerDialog;

    private volatile DatagramSocket socket;
    private volatile ServerSocket fileServer;
    private volatile boolean running;
    private WifiManager.MulticastLock multicastLock;

    // ---------- 表示用データ ----------

    private static class Item {
        String text;            // 通常メッセージ
        String prefix = "";     // ファイル行の「時刻 名前: 」
        String fileName;        // 非nullならファイル行
        long size;
        String key;             // 相手側のファイルキー
        String ip;              // 相手のIP
        File local;             // 保存済み/自分の送信ファイル
        boolean downloading;
        String status = "";

        public String toString() {
            if (fileName == null) return text;
            return prefix + "[ファイル] " + fileName + " (" + sizeStr(size) + ")  " + status;
        }
    }

    private static String sizeStr(long n) {
        if (n < 1024) return n + "B";
        if (n < 1024L * 1024) return (n / 1024) + "KB";
        return String.format("%.1fMB", n / (1024.0 * 1024.0));
    }

    private static String now() {
        return new SimpleDateFormat("HH:mm").format(new Date());
    }

    // ---------- ライフサイクル ----------

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        statusView = (TextView) findViewById(R.id.status);
        nameEdit = (EditText) findViewById(R.id.name);
        msgEdit = (EditText) findViewById(R.id.msg);
        ListView list = (ListView) findViewById(R.id.list);

        adapter = new ArrayAdapter<Item>(this, android.R.layout.simple_list_item_1);
        list.setAdapter(adapter);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View v, int pos, long id) {
                onItemTapped(adapter.getItem(pos));
            }
        });

        nameEdit.setText("user" + (new Random().nextInt(900) + 100));

        ((Button) findViewById(R.id.send)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                sendMessage();
            }
        });
        ((Button) findViewById(R.id.attach)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (!Environment.MEDIA_MOUNTED.equals(Environment.getExternalStorageState())) {
                    toast("SDカード(外部ストレージ)が使えません");
                    return;
                }
                showPicker(Environment.getExternalStorageDirectory());
            }
        });
        ((Button) findViewById(R.id.draw)).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                showDrawDialog();
            }
        });

        WifiManager wm = (WifiManager) getSystemService(Context.WIFI_SERVICE);
        multicastLock = wm.createMulticastLock("wifichat");
        multicastLock.setReferenceCounted(false);
        multicastLock.acquire();

        // 戻るキーで終了するまで、ホーム画面に移っても受信/ファイル提供を続ける
        running = true;
        startReceiver();
        startFileServer();
    }

    @Override
    protected void onStart() {
        super.onStart();
        updateStatus();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        running = false;
        DatagramSocket s = socket;
        if (s != null) s.close();
        ServerSocket fs = fileServer;
        if (fs != null) {
            try { fs.close(); } catch (Exception e) { /* ignore */ }
        }
        if (multicastLock.isHeld()) multicastLock.release();
    }

    private void updateStatus() {
        WifiManager wm = (WifiManager) getSystemService(Context.WIFI_SERVICE);
        String s;
        if (!wm.isWifiEnabled()) {
            s = "Wi-FiがOFFです";
            Toast.makeText(this, "Wi-FiをONにしてください", Toast.LENGTH_LONG).show();
        } else {
            WifiInfo info = wm.getConnectionInfo();
            if (info == null || info.getIpAddress() == 0) {
                s = "Wi-Fi未接続";
            } else {
                s = "SSID: " + info.getSSID() + " / IP: " + ipToString(info.getIpAddress())
                        + " / UDP " + PORT + " TCP " + FILE_PORT;
            }
        }
        statusView.setText(s);
    }

    private static String ipToString(int ip) {
        return (ip & 0xFF) + "." + ((ip >> 8) & 0xFF) + "." + ((ip >> 16) & 0xFF) + "."
                + ((ip >> 24) & 0xFF);
    }

    // ---------- UDP受信 ----------

    private void startReceiver() {
        new Thread(new Runnable() {
            public void run() {
                DatagramSocket s = null;
                try {
                    s = new DatagramSocket(null);
                    s.setReuseAddress(true);
                    s.setBroadcast(true);
                    s.bind(new InetSocketAddress(PORT));
                    socket = s;
                    byte[] buf = new byte[2048];
                    while (running) {
                        DatagramPacket p = new DatagramPacket(buf, buf.length);
                        s.receive(p);
                        handlePacket(p);
                    }
                } catch (Exception e) {
                    if (running) postLine("[受信エラー] " + e.getMessage());
                } finally {
                    if (s != null) s.close();
                    socket = null;
                }
            }
        }, "wifichat-recv").start();
    }

    private void handlePacket(DatagramPacket p) {
        try {
            String text = new String(p.getData(), 0, p.getLength(), "UTF-8");
            String[] parts = text.split(SEP, 5);
            if (parts.length < 5 || !MAGIC.equals(parts[0])) return;
            if (myId.equals(parts[2])) return; // 自分のエコーは無視
            String type = parts[1];
            String name = parts[3];
            String time = now();
            if ("M".equals(type)) {
                postLine(time + " " + name + ": " + parts[4]);
            } else if ("F".equals(type)) {
                String[] f = parts[4].split(SEP, 3); // key, size, filename
                if (f.length < 3) return;
                long size;
                try {
                    size = Long.parseLong(f[1]);
                } catch (NumberFormatException e) {
                    return;
                }
                Item it = new Item();
                it.prefix = time + " " + name + ": ";
                it.fileName = safeName(f[2]);
                it.size = size;
                it.key = f[0];
                it.ip = p.getAddress().getHostAddress();
                it.status = "タップで保存";
                postItem(it);
            }
        } catch (UnsupportedEncodingException e) {
            // UTF-8は必ず存在する
        }
    }

    // ---------- UDP送信 ----------

    private String myName() {
        String n = nameEdit.getText().toString().trim();
        if (n.length() == 0) n = "noname";
        return n.replace(SEP, " ").replace("\n", " ");
    }

    private void sendMessage() {
        String msg = msgEdit.getText().toString().trim();
        if (msg.length() == 0) return;
        String name = myName();
        String body = msg.replace(SEP, " ");

        postLine(now() + " " + name + "(自分): " + body);
        msgEdit.setText("");
        sendUdp("M", name, body);
    }

    private void sendUdp(String type, String name, String payload) {
        final InetAddress target = getBroadcastAddress();
        final String s = MAGIC + SEP + type + SEP + myId + SEP + name + SEP + payload;
        new Thread(new Runnable() {
            public void run() {
                try {
                    byte[] data = s.getBytes("UTF-8");
                    DatagramSocket ds = socket;
                    boolean temp = false;
                    if (ds == null) {
                        ds = new DatagramSocket();
                        ds.setBroadcast(true);
                        temp = true;
                    }
                    ds.send(new DatagramPacket(data, data.length, target, PORT));
                    if (temp) ds.close();
                } catch (Exception e) {
                    postLine("[送信エラー] " + e.getMessage());
                }
            }
        }, "wifichat-send").start();
    }

    private InetAddress getBroadcastAddress() {
        try {
            WifiManager wm = (WifiManager) getSystemService(Context.WIFI_SERVICE);
            DhcpInfo d = wm.getDhcpInfo();
            if (d != null && d.ipAddress != 0 && d.netmask != 0) {
                int b = (d.ipAddress & d.netmask) | ~d.netmask;
                byte[] q = new byte[4];
                for (int i = 0; i < 4; i++) {
                    q[i] = (byte) ((b >> (i * 8)) & 0xFF);
                }
                return InetAddress.getByAddress(q);
            }
        } catch (Exception e) {
            // フォールバックへ
        }
        try {
            return InetAddress.getByName("255.255.255.255");
        } catch (Exception e) {
            return null;
        }
    }

    // ---------- ファイル提供 (TCPサーバ) ----------

    private void startFileServer() {
        new Thread(new Runnable() {
            public void run() {
                ServerSocket ss = null;
                try {
                    ss = new ServerSocket();
                    ss.setReuseAddress(true);
                    ss.bind(new InetSocketAddress(FILE_PORT));
                    fileServer = ss;
                    while (running) {
                        final Socket c = ss.accept();
                        new Thread(new Runnable() {
                            public void run() {
                                serve(c);
                            }
                        }, "wifichat-serve").start();
                    }
                } catch (Exception e) {
                    if (running) postLine("[ファイルサーバエラー] " + e.getMessage());
                } finally {
                    if (ss != null) {
                        try { ss.close(); } catch (Exception e) { /* ignore */ }
                    }
                    fileServer = null;
                }
            }
        }, "wifichat-fileserver").start();
    }

    /** "GET <key>\n" を受け取り、共有登録済みのファイルだけを返す */
    private void serve(Socket c) {
        FileInputStream fis = null;
        try {
            c.setSoTimeout(15000);
            InputStream in = c.getInputStream();
            StringBuilder sb = new StringBuilder();
            int b;
            while ((b = in.read()) != -1 && b != '\n' && sb.length() < 100) {
                sb.append((char) b);
            }
            String line = sb.toString().trim();
            if (!line.startsWith("GET ")) return;
            File f = sharedFiles.get(line.substring(4).trim());
            if (f == null || !f.isFile()) return;

            fis = new FileInputStream(f);
            OutputStream out = c.getOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = fis.read(buf)) > 0) {
                out.write(buf, 0, n);
            }
            out.flush();
        } catch (Exception e) {
            // 相手が切断した場合など
        } finally {
            if (fis != null) {
                try { fis.close(); } catch (Exception e) { /* ignore */ }
            }
            try { c.close(); } catch (Exception e) { /* ignore */ }
        }
    }

    private void shareFile(File f) {
        if (!f.isFile()) {
            toast("ファイルを読めません");
            return;
        }
        String name = myName();
        String fname = f.getName().replace(SEP, " ").replace("\n", " ");
        String key = Long.toHexString(new Random().nextLong());
        sharedFiles.put(key, f);

        Item it = new Item();
        it.prefix = now() + " " + name + "(自分): ";
        it.fileName = fname;
        it.size = f.length();
        it.local = f;
        it.status = "共有中・タップで開く";
        postItem(it);

        sendUdp("F", name, key + SEP + f.length() + SEP + fname);
    }

    // ---------- ファイル受信 (TCPクライアント) ----------

    private void onItemTapped(Item it) {
        if (it == null || it.fileName == null) return;
        if (it.local != null && it.local.exists()) {
            openFile(it.local);
        } else if (it.ip != null && !it.downloading) {
            startDownload(it);
        }
    }

    private File saveDir() {
        if (!Environment.MEDIA_MOUNTED.equals(Environment.getExternalStorageState())) return null;
        File d = new File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                "WifiChat");
        d.mkdirs();
        return d;
    }

    private void startDownload(final Item it) {
        final File dir = saveDir();
        if (dir == null) {
            toast("SDカード(外部ストレージ)が使えません");
            return;
        }
        it.downloading = true;
        it.status = "接続中...";
        adapter.notifyDataSetChanged();

        new Thread(new Runnable() {
            public void run() {
                Socket s = null;
                FileOutputStream fos = null;
                File out = null;
                boolean ok = false;
                String err = null;
                try {
                    s = new Socket();
                    s.connect(new InetSocketAddress(it.ip, FILE_PORT), 5000);
                    s.setSoTimeout(15000);
                    OutputStream os = s.getOutputStream();
                    os.write(("GET " + it.key + "\n").getBytes("UTF-8"));
                    os.flush();
                    InputStream in = s.getInputStream();

                    out = uniqueFile(dir, it.fileName);
                    fos = new FileOutputStream(out);
                    byte[] buf = new byte[8192];
                    long got = 0;
                    long last = 0;
                    while (got < it.size) {
                        int n = in.read(buf, 0, (int) Math.min(buf.length, it.size - got));
                        if (n < 0) break;
                        fos.write(buf, 0, n);
                        got += n;
                        long t = System.currentTimeMillis();
                        if (t - last > 300) {
                            last = t;
                            setStatus(it, "保存中 " + (int) (got * 100 / it.size) + "%");
                        }
                    }
                    fos.close();
                    fos = null;
                    if (got == it.size) {
                        ok = true;
                    } else {
                        err = "途中で切断されました";
                    }
                } catch (Exception e) {
                    err = (e.getMessage() != null) ? e.getMessage() : e.toString();
                } finally {
                    if (fos != null) {
                        try { fos.close(); } catch (Exception e) { /* ignore */ }
                    }
                    if (s != null) {
                        try { s.close(); } catch (Exception e) { /* ignore */ }
                    }
                    if (!ok && out != null) out.delete();
                }

                final boolean fok = ok;
                final File fout = out;
                final String ferr = err;
                handler.post(new Runnable() {
                    public void run() {
                        it.downloading = false;
                        if (fok) {
                            it.local = fout;
                            it.status = "保存済み(Download/WifiChat)・タップで開く";
                        } else {
                            it.status = "失敗: " + ferr + " (タップで再試行)";
                        }
                        adapter.notifyDataSetChanged();
                    }
                });
            }
        }, "wifichat-download").start();
    }

    private void setStatus(final Item it, final String s) {
        handler.post(new Runnable() {
            public void run() {
                it.status = s;
                adapter.notifyDataSetChanged();
            }
        });
    }

    /** 相手から送られたファイル名を安全化 (パス区切り・FAT禁止文字を除去) */
    private static String safeName(String n) {
        n = n.replace('/', '_').replace('\\', '_').replace(':', '_').replace('*', '_')
                .replace('?', '_').replace('"', '_').replace('<', '_').replace('>', '_')
                .replace('|', '_').trim();
        while (n.startsWith(".")) n = n.substring(1);
        if (n.length() > 100) n = n.substring(n.length() - 100);
        if (n.length() == 0) n = "file";
        return n;
    }

    private static File uniqueFile(File dir, String name) {
        File f = new File(dir, name);
        if (!f.exists()) return f;
        int dot = name.lastIndexOf('.');
        String base = (dot > 0) ? name.substring(0, dot) : name;
        String ext = (dot > 0) ? name.substring(dot) : "";
        int i = 1;
        while (f.exists()) {
            f = new File(dir, base + "(" + i + ")" + ext);
            i++;
        }
        return f;
    }

    private void openFile(File f) {
        String name = f.getName();
        int dot = name.lastIndexOf('.');
        String ext = (dot >= 0) ? name.substring(dot + 1).toLowerCase() : "";
        String mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);
        if (mime == null) {
            toast("保存先: " + f.getAbsolutePath());
            return;
        }
        Intent in = new Intent(Intent.ACTION_VIEW);
        in.setDataAndType(Uri.fromFile(f), mime);
        try {
            startActivity(in);
        } catch (ActivityNotFoundException e) {
            toast("開けるアプリがありません。保存先: " + f.getAbsolutePath());
        }
    }

    // ---------- ファイル選択ダイアログ ----------

    private void showPicker(final File dir) {
        if (pickerDialog != null) pickerDialog.dismiss();

        File[] arr = dir.listFiles();
        final List<File> items = new ArrayList<File>();
        if (arr != null) {
            Arrays.sort(arr, new Comparator<File>() {
                public int compare(File a, File b) {
                    if (a.isDirectory() != b.isDirectory()) return a.isDirectory() ? -1 : 1;
                    return a.getName().compareToIgnoreCase(b.getName());
                }
            });
            for (File f : arr) {
                if (!f.getName().startsWith(".")) items.add(f);
            }
        }
        final File parent = dir.getParentFile();
        final boolean hasUp = (parent != null);

        List<String> labels = new ArrayList<String>();
        if (hasUp) labels.add("..  (上へ)");
        for (File f : items) {
            labels.add(f.isDirectory() ? "[DIR] " + f.getName()
                    : f.getName() + "  (" + sizeStr(f.length()) + ")");
        }

        AlertDialog.Builder b = new AlertDialog.Builder(this);
        b.setTitle(dir.getAbsolutePath());
        b.setItems(labels.toArray(new String[0]), new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface d, int which) {
                int idx = which;
                if (hasUp) {
                    if (which == 0) {
                        showPicker(parent);
                        return;
                    }
                    idx = which - 1;
                }
                File f = items.get(idx);
                if (f.isDirectory()) {
                    showPicker(f);
                } else {
                    shareFile(f);
                }
            }
        });
        b.setNegativeButton("キャンセル", null);
        pickerDialog = b.show();
    }

    // ---------- お絵描き ----------

    private void showDrawDialog() {
        final Dialog dlg = new Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        final DrawView dv = new DrawView(this);
        root.addView(dv, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.FILL_PARENT, 0, 1f));

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        addColorButton(row1, "黒", Color.BLACK, dv);
        addColorButton(row1, "赤", Color.RED, dv);
        addColorButton(row1, "青", Color.BLUE, dv);
        addColorButton(row1, "緑", Color.rgb(0, 140, 0), dv);
        addButton(row1, "消しゴム", new View.OnClickListener() {
            public void onClick(View v) {
                dv.setEraser();
            }
        });
        root.addView(row1, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.FILL_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        final String[] widthLabels = { "太さ:細", "太さ:中", "太さ:太" };
        addButton(row2, widthLabels[0], new View.OnClickListener() {
            public void onClick(View v) {
                ((Button) v).setText(widthLabels[dv.nextWidth()]);
            }
        });
        addButton(row2, "クリア", new View.OnClickListener() {
            public void onClick(View v) {
                dv.clear();
            }
        });
        addButton(row2, "送信", new View.OnClickListener() {
            public void onClick(View v) {
                File dir = saveDir();
                if (dir == null) {
                    toast("SDカード(外部ストレージ)が使えません");
                    return;
                }
                File out = new File(dir, "draw_"
                        + new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date()) + ".png");
                if (dv.saveTo(out)) {
                    dlg.dismiss();
                    shareFile(out);
                } else {
                    toast("画像の保存に失敗しました");
                }
            }
        });
        addButton(row2, "閉じる", new View.OnClickListener() {
            public void onClick(View v) {
                dlg.dismiss();
            }
        });
        root.addView(row2, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.FILL_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        dlg.setContentView(root);
        dlg.show();
    }

    private Button addButton(LinearLayout row, String label, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(label);
        b.setOnClickListener(l);
        row.addView(b, new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        return b;
    }

    private void addColorButton(LinearLayout row, String label, final int color,
            final DrawView dv) {
        Button b = addButton(row, label, new View.OnClickListener() {
            public void onClick(View v) {
                dv.setColor(color);
            }
        });
        b.setBackgroundColor(color);
        b.setTextColor(Color.WHITE);
    }

    private static class DrawView extends View {
        private static final float[] WIDTHS = { 4f, 10f, 22f };
        private final Paint paint = new Paint();
        private Bitmap bmp;
        private Canvas cv;
        private float lx, ly;
        private int widthIdx = 0;
        private boolean eraser = false;

        DrawView(Context c) {
            super(c);
            paint.setAntiAlias(true);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeJoin(Paint.Join.ROUND);
            paint.setColor(Color.BLACK);
            applyWidth();
        }

        private void applyWidth() {
            paint.setStrokeWidth(WIDTHS[widthIdx] * (eraser ? 2f : 1f));
        }

        void setColor(int c) {
            eraser = false;
            paint.setColor(c);
            applyWidth();
        }

        void setEraser() {
            eraser = true;
            paint.setColor(Color.WHITE);
            applyWidth();
        }

        int nextWidth() {
            widthIdx = (widthIdx + 1) % WIDTHS.length;
            applyWidth();
            return widthIdx;
        }

        void clear() {
            if (cv != null) {
                cv.drawColor(Color.WHITE);
                invalidate();
            }
        }

        boolean saveTo(File f) {
            if (bmp == null) return false;
            FileOutputStream fos = null;
            try {
                fos = new FileOutputStream(f);
                boolean r = bmp.compress(Bitmap.CompressFormat.PNG, 100, fos);
                fos.close();
                fos = null;
                return r;
            } catch (Exception e) {
                return false;
            } finally {
                if (fos != null) {
                    try { fos.close(); } catch (Exception e) { /* ignore */ }
                }
            }
        }

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) {
            if (w <= 0 || h <= 0) return;
            Bitmap nb = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            Canvas nc = new Canvas(nb);
            nc.drawColor(Color.WHITE);
            if (bmp != null) nc.drawBitmap(bmp, 0, 0, null);
            bmp = nb;
            cv = nc;
        }

        @Override
        protected void onDraw(Canvas c) {
            if (bmp != null) c.drawBitmap(bmp, 0, 0, null);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (cv == null) return true;
            float x = e.getX();
            float y = e.getY();
            switch (e.getAction()) {
            case MotionEvent.ACTION_DOWN:
                lx = x;
                ly = y;
                cv.drawPoint(x, y, paint);
                invalidate();
                break;
            case MotionEvent.ACTION_MOVE:
                int hs = e.getHistorySize();
                for (int i = 0; i < hs; i++) {
                    float hx = e.getHistoricalX(i);
                    float hy = e.getHistoricalY(i);
                    cv.drawLine(lx, ly, hx, hy, paint);
                    lx = hx;
                    ly = hy;
                }
                cv.drawLine(lx, ly, x, y, paint);
                lx = x;
                ly = y;
                invalidate();
                break;
            default:
                break;
            }
            return true;
        }
    }

    // ---------- UIスレッド補助 ----------

    private void postItem(final Item it) {
        handler.post(new Runnable() {
            public void run() {
                adapter.add(it);
            }
        });
    }

    private void postLine(String line) {
        Item it = new Item();
        it.text = line;
        postItem(it);
    }

    private void toast(final String s) {
        handler.post(new Runnable() {
            public void run() {
                Toast.makeText(ChatActivity.this, s, Toast.LENGTH_LONG).show();
            }
        });
    }
}
