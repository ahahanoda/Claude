#!/bin/bash
# Gradle不使用。Android SDK付属ツール(aapt2/d8/apksigner)で直接APKを作る。
set -euo pipefail
cd "$(dirname "$0")"

SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-/usr/local/lib/android/sdk}}"
BT="$SDK/build-tools/$(ls "$SDK/build-tools" | grep -E '^[0-9.]+$' | sort -V | tail -1)"
AJAR="$SDK/platforms/$(ls "$SDK/platforms" | grep -E '^android-[0-9]+$' | sort -V | tail -1)/android.jar"
echo "build-tools: $BT"
echo "android.jar: $AJAR"

rm -rf build
mkdir -p build/compiled build/gen build/classes build/dex

# 1) リソース
"$BT/aapt2" compile --dir res -o build/compiled
"$BT/aapt2" link -o build/base.apk -I "$AJAR" \
  --manifest AndroidManifest.xml \
  --min-sdk-version 9 --target-sdk-version 10 \
  --java build/gen build/compiled/*.flat

# 2) Javaコンパイル (Java 8バイトコード。コードはAPI 10のAPIのみ使用)
javac --release 8 -Xlint:-options -encoding UTF-8 -classpath "$AJAR" \
  -d build/classes $(find src build/gen -name '*.java')

# 3) dex化 (Android 2.3向け min-api 9)
"$BT/d8" --release --min-api 9 --lib "$AJAR" --output build/dex \
  $(find build/classes -name '*.class')

# 4) APKに追加 → zipalign → 署名
(cd build/dex && zip -q ../base.apk classes.dex)
"$BT/zipalign" -f -p 4 build/base.apk build/aligned.apk

keytool -genkeypair -keystore build/key.jks -storepass android -keypass android \
  -alias key -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=WifiChat"

# Android 2.3 は v1(JAR)署名のみ対応なので min-sdk 9 を指定
"$BT/apksigner" sign --ks build/key.jks --ks-pass pass:android --key-pass pass:android \
  --min-sdk-version 9 --v1-signing-enabled true \
  --out build/WifiChat.apk build/aligned.apk
"$BT/apksigner" verify -v build/WifiChat.apk | head -8

ls -l build/WifiChat.apk
