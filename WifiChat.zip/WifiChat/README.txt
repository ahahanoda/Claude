WiFiチャット (SH-02D / Android 2.3.5 / API 10)

■ ビルド方法
A) Eclipse + ADT: File > New > Android Project (From Existing Source) でこのフォルダを選択。
   Build Target は Android 2.3.3 (API 10)。
B) 新規プロジェクトを作り、AndroidManifest.xml / res / src を置き換えてもOK。
   (package: com.example.wifichat, 最小SDK 9)

■ 使い方
1. 複数台を同じWi-Fiに接続し、各端末でアプリを起動。
2. 名前を入力してメッセージを送信。UDPブロードキャスト(ポート50000)なのでサーバ不要。

■ 注意
- ルータの「AP分離(プライバシーセパレータ)」が有効だと届きません。
- 通信は暗号化されません(同一LAN内の簡易チャット用)。
